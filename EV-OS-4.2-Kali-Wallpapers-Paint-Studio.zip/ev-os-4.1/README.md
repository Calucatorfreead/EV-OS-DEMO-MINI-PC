# EV OS 4.1 — Music Studio Update

A browser-based Windows-inspired desktop demo built with HTML, CSS, and JavaScript.

## What's new in 4.1
- EV Music Studio with a neon player, local multi-file playlist, Play and Remove controls.
- Playlist idea labels: Aura Farming, Montagem Delério, and Abnormal. These are labels only; no copyrighted recordings are bundled. Add audio files you own or are allowed to use.
- EV Store apps now show a 5-second install countdown; once installation completes, the app shortcut appears on the desktop and stays saved in this browser.
- Settings includes a clearly marked simulated device profile showing 2 TB SSD and 32 GB RAM. These are cosmetic demo specifications and do not change the real computer's hardware or browser storage limits.
- Windows-inspired UI sound effects remain available, and the sound setting can turn them off.

## Publish on GitHub Pages
1. Extract the ZIP.
2. Upload `index.html` to the root of your repository and replace the previous file.
3. Commit the changes.
4. Wait for GitHub Pages to deploy, then hard-refresh with Ctrl+F5.

## Important limits
- This is a website simulation, not a real operating system installer.
- Music files are selected locally and are not uploaded to a server. Browser object URLs are temporary; re-add the tracks after closing/reloading the page.
- The 2 TB / 32 GB profile is fictional display text only.
- Login is a demo and must not be used with a real password.
- Browser local storage is limited by the browser and is not a real 2 TB drive.
